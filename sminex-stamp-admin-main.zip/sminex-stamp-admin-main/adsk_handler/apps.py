from django.apps import AppConfig


class AdskHandlerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "adsk_handler"
